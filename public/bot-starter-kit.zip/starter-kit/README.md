
# 🔥 Smart Telegram AI Bot Template

Create your own **AI-powered Telegram bot** that can answer questions, assist with productivity, or plug into your own project or business. Powered by **OpenAI**, **LLaMA (via Ollama)**, or both — you decide.

This template gives you a running start. Plug it in, run it, and you’ve got a smart assistant in Telegram responding to keywords in chat.

---

## 🚀 Features

- 🧠 Responds to trigger words like "bot", "ai", or "assistant"
- ⚡ Uses **Ollama** (LLaMA 3) locally with fallback to **OpenAI GPT-4**
- 🛠 Built with Node.js, Telegraf, and Fetch
- 🌐 Works in both group chats and private chats
- 🧩 Easily extend with MongoDB if you want memory or user profiles

---

## 📦 Tech Stack

| Library/Service | Purpose                      | Optional? | Notes |
|-----------------|------------------------------|-----------|-------|
| `telegraf`      | Telegram bot framework       | No        | Core interaction engine |
| `openai`        | GPT-4 fallback               | Yes       | Only used if Ollama fails |
| `node-fetch`    | Makes HTTP requests          | No        | Used for calling APIs |
| `p-timeout`     | Adds timeout to API requests | No        | Prevents bot from hanging |
| `dotenv`        | Loads env variables          | No        | `.env` file required |
| `ollama`        | Local LLaMA model            | Yes       | Requires Ollama setup |

---

## 📂 Folder Structure

```
.
├── bot.js              # Main bot logic
├── .env                # Store your tokens & API keys
├── package.json        # Dependencies
└── README.md           # This file
```

---

## ⚙️ Setup Instructions

### 1. Clone the Repo

```bash
git clone https://github.com/yourrepo/unplugged-ai-bot-template.git
cd unplugged-ai-bot-template
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Create a `.env` File

```env
BOT_TOKEN=your_telegram_bot_token
OPENAI_API_KEY=sk-xxxxxxxxxxxx         # optional, for OpenAI fallback
OLLAMA_URL=http://localhost:11434/api/generate  # optional, for LLaMA
```

### 4. Run the Bot

```bash
npm start
```

---

## 🧠 How It Works

- User types a message like:
  > “Hey ai, what’s the best marketing tip right now?”
- If it contains trigger words (`bot`, `ai`, `@`, `assistant`), the bot replies.
- LLaMA via **Ollama** is tried first (fast & local).
- If that fails, GPT-4 via **OpenAI API** is used as fallback (if `OPENAI_API_KEY` is set).

---

## 💾 Model Sizes (If Using Ollama)

If you use **LLaMA via Ollama**, you'll need to download models:

| Model      | Size     | Command                           |
|------------|----------|-----------------------------------|
| `llama3`   | ~4.7 GB  | `ollama run llama3`               |
| `codellama`| ~3.8 GB  | `ollama run codellama` (optional) |

Install Ollama from: https://ollama.com/download

---

## 🌐 OpenAI-Only Option

If you don’t want to run anything locally, just set your `.env` like this:

```env
BOT_TOKEN=your_token
OPENAI_API_KEY=your_openai_key
# Don’t set OLLAMA_URL
```

The bot will skip local models and go straight to GPT-4 responses.

---

## 🛠 Extend & Customize

Want to save user chats to MongoDB? Track engagement? Integrate external APIs?

You can expand the `bot.js` file with:

- MongoDB for memory
- Custom triggers
- Different personalities
- Command-based utilities (`/tools`, `/alpha`, `/help`, etc.)

---

## 🙋 Need Help?

You’re not alone.

📩 **DM [@TheLastShedded](https://t.me/TheLastShedded)**  
👥 Or ask in the **Unplugged Community Telegram Group**

---

## 🧪 Example Prompt

```txt
You are a helpful, concise assistant that specializes in business, crypto, and high performance. Avoid fluff. Reply to this input:

“What’s the best marketing move for a Solana project right now?”
```

---

## 🔓 License

MIT — use it, remix it, build something powerful.
