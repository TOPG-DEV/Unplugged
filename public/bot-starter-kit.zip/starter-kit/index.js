// SMART TELEGRAM AI BOT TEMPLATE
import 'dotenv/config';
import { Telegraf } from 'telegraf';
import fetch from 'node-fetch';
import pTimeout from 'p-timeout';

const BOT_TOKEN = process.env.BOT_TOKEN;
const OLLAMA_URL = process.env.OLLAMA_URL || 'http://localhost:11434/api/generate'; // For LLaMA via Ollama
const OPENAI_API_KEY = process.env.OPENAI_API_KEY; // For OpenAI fallback

if (!BOT_TOKEN) throw new Error('Missing BOT_TOKEN in .env');
const bot = new Telegraf(BOT_TOKEN);

// You can optionally connect to MongoDB here if you want to add memory/user profiles

// === BASE FUNCTION TO BUILD A LLM PROMPT ===
function buildPrompt(userMessage) {
  return `You are a helpful, concise assistant that specializes in business, crypto, and high performance. Avoid fluff. Reply to this input:\n\n"${userMessage}"`;
}

// === OLLAMA HANDLER ===
async function fetchFromOllama(prompt) {
  const res = await fetch(OLLAMA_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: 'llama3', prompt, stream: false })
  });

  if (!res.ok) throw new Error(`Ollama responded with ${res.status}`);
  const data = await res.json();
  return data.response?.trim() || 'No response from LLaMA.';
}

// === OPENAI FALLBACK ===
async function fetchFromOpenAI(prompt) {
  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${OPENAI_API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: 'gpt-4',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.7
    })
  });

  const data = await res.json();
  return data.choices?.[0]?.message?.content?.trim() || 'No response from OpenAI.';
}

// === MAIN AI QUERY FUNCTION ===
async function queryLLM(input) {
  const prompt = buildPrompt(input);

  try {
    const response = await pTimeout(fetchFromOllama(prompt), 15000); // 15s timeout
    console.log('✅ Replied via Ollama');
    return response;
  } catch (ollamaErr) {
    console.warn('⚠️ Ollama failed, using OpenAI fallback...');
    if (!OPENAI_API_KEY) return 'LLM failed and no OpenAI key was set.';
    try {
      return await fetchFromOpenAI(prompt);
    } catch (openaiErr) {
      console.error('OpenAI failed:', openaiErr);
      return '❌ All engines failed. Try again later.';
    }
  }
}

// === TEXT MESSAGE HANDLER ===
bot.on('text', async (ctx) => {
  const input = ctx.message?.text;
  if (!input) return;

  const lower = input.toLowerCase();
  const triggerWords = ['ai', 'bot', '@', 'assistant']; // Customize
  const isTriggered = triggerWords.some(t => lower.includes(t));

  if (isTriggered) {
    await ctx.replyWithChatAction('typing');
    const reply = await queryLLM(input);
    return ctx.reply(reply);
  }
});

// === START + HELP COMMAND ===
bot.start((ctx) =>
  ctx.reply(`Welcome to your AI bot. Type a message and include words like "bot" or "ai" to trigger a smart reply.`)
);

bot.help((ctx) =>
  ctx.reply(`💡 How to Use:\nJust send a message with a trigger word like "ai", "bot", or "@", and the assistant will respond using LLaMA or OpenAI.`)
);

// === DEPLOY ===
bot.launch();
console.log('🤖 AI Bot is running.');

process.once('SIGINT', () => process.exit(0));
process.once('SIGTERM', () => process.exit(0));
